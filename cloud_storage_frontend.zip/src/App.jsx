
export default function App(){
  return <h1>Cloud Storage Frontend Running</h1>;
}
